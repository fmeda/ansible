# Biblioteca Ansible - Data Center Multivendor + Reports

Fluxo: Analista -> Jump Server -> Red Hat/Ansible -> Inventário -> Playbooks -> Cisco/Huawei/Dell/VMware/Storage -> Evidências -> HTML/CSV/JSON.

## Instalação
ansible-galaxy collection install -r requirements.yml

## Validação
ansible-inventory --graph
ansible-playbook site.yml --syntax-check
ansible-playbook site.yml --check

## Execução
ansible-playbook site.yml

## Arquivos gerados
reports/dc_report.html
reports/dc_inventory.csv
reports/dc_report.json
evidence/*

## Adaptação
1. Altere IPs em inventory/hosts.yml.
2. Ajuste ansible_network_os nas group_vars.
3. Ajuste comandos por modelo/release.
4. Configure credenciais via Ansible Vault/AAP Credential/Secret Manager.
5. Valide primeiro em grupo piloto.

A arquitetura usa network_cli/cli_command para dispositivos CLI e templates Jinja2 para o relatório; para VMware usa community.vmware. Consulte a documentação oficial antes de produção.
